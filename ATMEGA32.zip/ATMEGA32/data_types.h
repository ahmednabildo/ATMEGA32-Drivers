/*
 * data_types.h
 *
 * Created: 29/03/2024 06:49:10
 *  Author: DELL
 */ 


#ifndef DATA_TYPES_H_
#define DATA_TYPES_H_


typedef unsigned char uint8_t;
typedef unsigned int uint16_t;
typedef unsigned long long uint32__t;
typedef float float_t;


#endif /* DATA_TYPES_H_ */