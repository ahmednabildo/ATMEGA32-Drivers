/*
 * SPI.c
 *
 * Created: 14/04/2024 15:01:14
 *  Author: DELL
 */ 
#include "SPI.h"

void SPI_INIT(SPI_Configuration_t *confg)
{
    SET_BIT(SPCR , 6);

    if(confg->mode == master)
    {
        SET_BIT(DDRB , 4);
        SET_BIT(DDRB , 5);
        SET_BIT(DDRB , 7);
        CLEAR_BIT(DDRB , 6);
        SET_BIT(PORTB , 4);
        SET_BIT(SPCR , 4);
    }
    else if(confg->mode == slave)
    {
        CLEAR_BIT(DDRB , 4);
        CLEAR_BIT(DDRB , 5);
        CLEAR_BIT(DDRB , 7);
        SET_BIT(DDRB , 6);
        CLEAR_BIT(SPCR , 4);
    }

    if(confg->trans_speed == normal_speed)
    {
        CLEAR_BIT(SPSR , 0);
    }
    else if(confg->trans_speed == double_speed)
    {
        SET_BIT(SPSR , 0);
    }

    if(confg->interrupt == INT_EN)
    {
        SET_BIT(SPCR , 7);
    }
    else if(confg->interrupt == INT_DIS)
    {
        CLEAR_BIT(SPCR , 7);
    }

    if(confg->data_order == MSB)
    {
        CLEAR_BIT(SPCR , 5);
    }
    else if(confg->data_order == LSB)
    {
        SET_BIT(SPCR , 5);
    }

    if(confg->clk_polarity == falling)
    {
        SET_BIT(SPCR , 3);
    }
    else if(confg->clk_polarity == rising)
    {
        CLEAR_BIT(SPCR , 3);
    }

    if(confg->clk_phase == sample)
    {
        CLEAR_BIT(SPCR , 2);
    }
    else if(confg->clk_phase == setup)
    {
        SET_BIT(SPCR , 2);
    }

    if(confg->clk_rate == normal_speed_freq_4)
    {
        CLEAR_BIT(SPCR , 0);
        CLEAR_BIT(SPCR , 1);
    }
    else if(confg->clk_rate == normal_speed_freq_16)
    {
        SET_BIT(SPCR , 0);
        CLEAR_BIT(SPCR , 1);
    }
    else if(confg->clk_rate == normal_speed_freq_64)
    {
        CLEAR_BIT(SPCR , 0);
        SET_BIT(SPCR , 1);
    }
    else if(confg->clk_rate == normal_speed_freq_128)
    {
        SET_BIT(SPCR , 0);
        SET_BIT(SPCR , 1);
    }

    if(confg->clk_rate == double_speed_freq_2)
    {
        CLEAR_BIT(SPCR , 0);
        CLEAR_BIT(SPCR , 1);
    }
    else if(confg->clk_rate == double_speed_freq_8)
    {
        SET_BIT(SPCR , 0);
        CLEAR_BIT(SPCR , 1);
    }
    else if(confg->clk_rate == double_speed_freq_32)
    {
        CLEAR_BIT(SPCR , 0);
        SET_BIT(SPCR , 1);
    }
    else if(confg->clk_rate == double_speed_freq_64)
    {
        SET_BIT(SPCR , 0);
        SET_BIT(SPCR , 1);
    }


}
void SPI_TRANS(uint8_t  data , uint8_t *data_)
{
    CLEAR_BIT(PORTB , 4);
    SPDR = data;
    while ((READ_BIT(SPSR , 7)) == 0);
    *data_ = SPDR;
    SET_BIT(PORTB , 4);
}
void SPI_REC(uint8_t *data)
{
    SPDR = 0;
    while ((READ_BIT(SPSR , 7)) == 0);
    *data = SPDR;
}