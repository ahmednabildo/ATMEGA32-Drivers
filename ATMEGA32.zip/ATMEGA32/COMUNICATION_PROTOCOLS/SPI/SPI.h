/*
 * SPI.h
 *
 * Created: 14/04/2024 15:01:25
 *  Author: DELL
 */ 


#ifndef SPI_H_
#define SPI_H_
#include "../../bit_wise.h"
#include "../../data_types.h"
#include "../../REGISTERS.h"

#define INT_EN 0
#define INT_DIS 1

#define MSB 0
#define LSB 1

#define master 0
#define slave 1

#define rising 0
#define falling 1

#define sample 0
#define setup 1

#define normal_speed 0
#define double_speed 1

#define normal_speed_freq_4 0
#define normal_speed_freq_16 1
#define normal_speed_freq_64 2
#define normal_speed_freq_128 3

#define double_speed_freq_2 0
#define double_speed_freq_8 1
#define double_speed_freq_32 2
#define double_speed_freq_64 3


typedef struct
{
    uint8_t trans_speed;
    uint8_t clk_polarity;
    uint8_t interrupt;
    uint8_t data_order;
    uint8_t clk_phase;

    uint8_t mode;
    uint8_t clk_rate;
}SPI_Configuration_t;

void SPI_INIT(SPI_Configuration_t *confg);
void SPI_TRANS(uint8_t data , uint8_t *data_);
void SPI_REC(uint8_t *data);


#endif /* SPI_H_ */